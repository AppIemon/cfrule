# 끝말잇기 전수 평가기 — 배포용

정적 파일만으로 동작합니다. 빌드 단계, 서버, 의존성이 없습니다.

## 구성

| 파일 | 설명 |
|---|---|
| `index.html` | 앱 전체 (사전 548,599단어 + 루트 4,333개 내장, 약 6.5MB) |
| `sw.js` | 서비스 워커. 앱 셸 캐시 → 재방문 즉시 로딩, 오프라인 동작 |
| `manifest.webmanifest` | PWA 매니페스트 (홈 화면 추가 시 전체화면) |
| `icon*.png`, `icon.svg`, `apple-touch-icon.png` | 아이콘 |
| `vercel.json` | 캐시 헤더 설정 |

## Vercel 배포

### 방법 1 — CLI

```bash
npm i -g vercel
cd deploy
vercel          # 미리보기 배포
vercel --prod   # 프로덕션 배포
```

프로젝트 설정 프롬프트에서:
- Framework Preset: **Other**
- Build Command: 비워두기
- Output Directory: 비워두기 (루트 그대로 서빙)

### 방법 2 — GitHub 연동

```bash
cd deploy
git init && git add . && git commit -m "끝말잇기 전수 평가기"
git branch -M main
git remote add origin https://github.com/<사용자명>/<저장소>.git
git push -u origin main
```

vercel.com → Add New Project → 저장소 선택 → Framework Preset **Other** → Deploy.

### 방법 3 — 드래그 앤 드롭

vercel.com/new 에서 `deploy` 폴더를 그대로 끌어다 놓아도 됩니다.

## 배포 후 확인

1. 첫 로딩에 사전 파싱이 들어가므로 모바일에서 3~6초 걸립니다.
2. 새로고침 시 즉시 뜨면 서비스 워커가 붙은 것입니다.
3. iOS Safari → 공유 → 홈 화면에 추가 시 전체화면으로 실행됩니다.

## 앱을 갱신할 때

`index.html`을 교체한 뒤 `sw.js`의 `CACHE` 값을 `kkutu-eval-v2` 처럼 올려야
기존 방문자에게 새 버전이 확실히 전달됩니다.
